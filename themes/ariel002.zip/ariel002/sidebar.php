		<div id="sidebar">
		
			<?php if( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>

			<div class="double-rule mobile"></div>
		
			<div class="side_box">
				<h3 class="side_title">Widget</h3>
				
			
			</div><!--//side_box-->
			
			<div class="side_box">
				<h3 class="side_title">Widget</h3>
				
				
			</div><!--//side_box-->			
			
			<?php endif; ?>
			
		</div>